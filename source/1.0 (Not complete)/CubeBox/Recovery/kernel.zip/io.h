#include "asm.h"
void putc(char c, char attr);